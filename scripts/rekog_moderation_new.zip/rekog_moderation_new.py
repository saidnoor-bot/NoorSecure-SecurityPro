import boto3
import json

def lambda_handler(event, context):
    print("Raw event:", json.dumps(event))

    # Parse SNS-wrapped S3 event
    sns_message = event['Records'][0]['Sns']['Message']
    s3_event = json.loads(sns_message)

    bucket = s3_event['Records'][0]['s3']['bucket']['name']
    key = s3_event['Records'][0]['s3']['object']['key']

    print(f"Bucket: {bucket}, Key: {key}")

    # Detect moderation labels using Rekognition
    rekog = boto3.client('rekognition')
    response = rekog.detect_moderation_labels(
        Image={'S3Object': {'Bucket': bucket, 'Name': key}},
        MinConfidence=80
    )

    labels = [label['Name'] for label in response['ModerationLabels']]

    # 🚨 If flagged, copy image to 'flagged/' folder in same bucket
    if labels:
        s3 = boto3.client('s3')
        copy_source = {'Bucket': bucket, 'Key': key}
        dest_key = 'flagged/' + key.split('/')[-1]  # just the filename
        s3.copy_object(CopySource=copy_source, Bucket=bucket, Key=dest_key)

    # 📨 Compose SNS message
    if labels:
        alert = f"🚨 Moderation Alert\n\nThe image '{key}' in bucket '{bucket}' was flagged for:\n"
        for label in labels:
            alert += f"- {label}\n"
    else:
        alert = f"✅ No moderation labels found for '{key}' in '{bucket}'."

    # 📣 Send SNS Notification
    sns = boto3.client('sns')
    sns.publish(
        TopicArn='arn:aws:sns:us-east-1:429128462098:S3UploadAlerts',
        Subject='Image Moderation Result',
        Message=alert
    )

    return {
        'statusCode': 200
    }

